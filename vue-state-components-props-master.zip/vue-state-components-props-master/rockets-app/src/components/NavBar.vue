<template lang="html">
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Rockets</a>
  </nav>
</template>
